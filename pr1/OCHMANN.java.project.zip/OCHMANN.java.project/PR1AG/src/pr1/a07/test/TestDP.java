package pr1.a07.test;

import schimkat.berlin.lernhilfe2024ws.graphics.FunnyFirstPainterTest;

public class TestDP {
	public static void main(String[] args) {
		FunnyFirstPainterTest.main(null);
	}
}
