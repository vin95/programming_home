package pr2.a08;

public class Command{
	public final static String SMILEY_SIZE_INC = "SMILEY_SIZE_INC";
	public final static String SMILEY_SIZE_DEC = "SMILEY_SIZE_DEC";
	public final static String SMILEY_EYE_INC = "SMILEY_EYE_INC";
	public final static String SMILEY_EYE_DEC = "SMILEY_EYE_DEC";
	public final static String SLIDER_CHANGE_SIZE = "SLIDER_CHANGE_SIZE";
	public final static String SLIDER_CHANGE_EYES = "SLIDER_CHANGE_EYES";
}
